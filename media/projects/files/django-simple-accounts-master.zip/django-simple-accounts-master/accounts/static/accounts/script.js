// django-simple-accounts JavaScript
